<?php
return [
    'video'=>[
        'ext'=>'mp4',
    ],
    'img'=>[
        'ext'=>'jpg,png,gif,webp'
    ]
];